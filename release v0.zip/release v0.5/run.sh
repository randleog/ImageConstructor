#!/bin/bash
java --enable-preview --module-path "libs/" --add-modules javafx.controls,javafx.fxml -jar ImageConstructor-1.0-SNAPSHOT.jar
